package com.cheakup;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.NullPointerException;

@WebServlet("/Cheaked")
public class Cheaked extends HttpServlet {
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		 String cold,fever,cough,headache,vomiting,mpain;
		 float bpr,diabetes;
		 PrintWriter out=response.getWriter();
			
		 cold=request.getParameter("cold");
		 fever=request.getParameter("fever");
		 cough=request.getParameter("cough");
		 headache=request.getParameter("head");
		 mpain=request.getParameter("muscle");
		 vomiting=request.getParameter("vomiting");
		 bpr=Float.parseFloat(request.getParameter("bldpre"));
		 diabetes=Float.parseFloat(request.getParameter("diabetes"));
		 	 
		 
		 try
		 {
		 if( bpr<=120 && bpr>=90 )
		 {
			 out.println("your blood pressure is normal");
		 }
		 else if(bpr<=90)	
		 {
			 
			 out.println("you are suffering from low blood pressure");
			 response.sendRedirect("emergency.html");
		 }
		 else if(bpr>=120)	
		 {
			 
			 out.println("you are suffering from high blood pressure");
			 response.sendRedirect("dr.html");
		 }
		 else
		 {
			 out.println("please write a right value");
		 }
		
		if(diabetes>140 && diabetes<=200)
		{
			 out.println("your sugar level is normal");
		}
		else if(diabetes>140 && diabetes<=200) 
		{
			 out.println("your sugar level is on predibetes");
		}
		else if(diabetes>200)
		{
			 out.println("you have a high diabetes level");
			 response.sendRedirect("emergency.html");
		}
		 
		 if(cold.equalsIgnoreCase("cold") && fever.equalsIgnoreCase("fever") && bpr<=90 && cough.equalsIgnoreCase("cough") && headache.equalsIgnoreCase("head"))
		 {
			 out.println("you have have a symptoms of Maleria so you should visit docotor");
			 response.sendRedirect("emergency.html");
			 
		 }
		
		 
		 if(vomiting.equalsIgnoreCase("Vomiting") && mpain.equalsIgnoreCase("Muscle Pain") && bpr<=90 && cold.equalsIgnoreCase("cold") && fever.equalsIgnoreCase("fever") && cough.equalsIgnoreCase("cough") && headache.equalsIgnoreCase("head"))
		 {
			 out.println("you have have a symptoms of Typhoid so you should visit docotor");
			 response.sendRedirect("emergency.html");
			 
		 }
		 }
		 catch(Exception e)
		 {
			 
			 out.println(e.getMessage());
			 
		 }
		 
			}

}
